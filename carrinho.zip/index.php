<?php
require_once("cabecalho.php");
require_once("conexao.php");
@session_start();
?>

 


<!-- Hero Section Begin -->
<section class="hero hero-mobile">
  <div class="container">
    <div class="row">
      <div class="col-lg-3">
        <div class="hero__categories">
          <div class="hero__categories__all">
            <i class="fa fa-bars"></i>
            <span>Categorias</span>
          </div>
          <ul>
            <?php 
            $query = $pdo->query("SELECT * FROM sub_categorias order by nome asc ");
            $res = $query->fetchAll(PDO::FETCH_ASSOC);

            for ($i=0; $i < count($res); $i++) { 
              foreach ($res[$i] as $key => $value) {
              }

              $nome = $res[$i]['nome'];

              $nome_url = $res[$i]['nome_url'];
              $id = $res[$i]['id'];
              ?>
              <li><a href="produtos-<?php echo $nome_url ?>"><?php echo $nome ?></a></li>

              <?php } ?>
          </ul>
        </div>
      </div>
      <div class="col-lg-9">
        <div class="hero__search">
          <div class="hero__search__form">
           <form action="lista-produtos.php" method="get">

            <input name="txtBuscar" type="text" placeholder="Deseja buscar um Produto?">
            <button type="submit" class="site-btn">BUSCAR</button>
          </form>
        </div>
      </div>
      <div class="hero__item set-bg bg-light" data-setbg="img/hero/banner.jpg">
        <div class="hero__text">
          <span>São Sebastião, Caraguatatuba <br>e Ilhabela</span>
          <h2>Pague <br /> na Entrega</h2>
          <p>Compre hoje, recebe em 3 á 7 dias</p>
          <a href="lista-produtos.php" class="primary-btn">VER TODOS MODELOS</a>
        </div>
      </div>
    </div>
  </div>
</div>
</section>
<!-- Hero Section End -->

<!-- Categories Section Begin -->
<section class="categories">
  <div class="container">
    <div class="row">
      <div class="categories__slider owl-carousel">

       <?php 
       $query = $pdo->query("SELECT * FROM sub_categorias order by id ");
       $res = $query->fetchAll(PDO::FETCH_ASSOC);

       for ($i=0; $i < count($res); $i++) { 
        foreach ($res[$i] as $key => $value) {
        }

        $nome = $res[$i]['nome'];
        $imagem = $res[$i]['imagem'];
        $nome_url = $res[$i]['nome_url'];

        ?>

        <div class="col-lg-3">
          <div class="categories__item set-bg" data-setbg="img/sub-categorias/<?php echo $imagem ?>">
            <h5><a href="produtos-<?php echo $nome_url ?>"><?php echo $nome ?></a></h5>
          </div>
        </div>

      <?php } ?>

    </div>
  </div>
</div>
</section>
<!-- Categories Section End -->




<section class="latest-product spad">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-6">
        <div class="latest-product__text">
          <h4>Novidades</h4>
          <div id="novosProdutos" class="latest-product__slider owl-carousel">
            <div class="latest-prdouct__slider__item">

              <?php 
              $query = $pdo->query("SELECT * FROM produtos order by id desc limit 3 ");
              $res = $query->fetchAll(PDO::FETCH_ASSOC);

              for ($i=0; $i < count($res); $i++) { 
                foreach ($res[$i] as $key => $value) {
                }

                $nome = $res[$i]['nome'];
                $valor = $res[$i]['valor'];
                $nome_url = $res[$i]['nome_url'];
                $imagem = $res[$i]['imagem'];
                $promocao = $res[$i]['promocao'];
                $id = $res[$i]['id'];

                if($promocao == 'Sim'){
                  $queryp = $pdo->query("SELECT * FROM promocoes where id_produto = '$id' ");
                  $resp = $queryp->fetchAll(PDO::FETCH_ASSOC);
                  $valor = $resp[0]['valor'];
                  $valor = number_format($valor, 2, ',', '.');
                }else{
                  $valor = number_format($valor, 2, ',', '.');
                }

                ?>


                <a href="produto-<?php echo $nome_url ?>" class="latest-product__item">
                <div class="latest-product__item__pic">
                    <img src="img/produtos/<?php echo $imagem ?>" alt="">
                </div>
                <div class="latest-product__item__text">
                    <h6><?php echo $nome ?></h6>
                    <span>R$ <?php echo $valor ?></span>
                </div>
            </a>

              <?php } ?>


            </div>


            <div class="latest-prdouct__slider__item">

              <?php 
              $query = $pdo->query("SELECT * FROM produtos where ativo = 'Sim' and estoque > 0 order by id desc limit 3,3 ");
              $res = $query->fetchAll(PDO::FETCH_ASSOC);

              for ($i=0; $i < count($res); $i++) { 
                foreach ($res[$i] as $key => $value) {
                }

                $nome = $res[$i]['nome'];
                $valor = $res[$i]['valor'];
                $nome_url = $res[$i]['nome_url'];
                $imagem = $res[$i]['imagem'];
                $promocao = $res[$i]['promocao'];
                $id = $res[$i]['id'];

                if($promocao == 'Sim'){
                  $queryp = $pdo->query("SELECT * FROM promocoes where id_produto = '$id' ");
                  $resp = $queryp->fetchAll(PDO::FETCH_ASSOC);
                  $valor = $resp[0]['valor'];
                  $valor = number_format($valor, 2, ',', '.');
                }else{
                  $valor = number_format($valor, 2, ',', '.');
                }


                ?>


                <a href="produto-<?php echo $nome_url ?>" class="latest-product__item">
                    <div class="latest-product__item__pic">
                        <img src="img/produtos/<?php echo $imagem ?>" alt="">
                    </div>
                    <div class="latest-product__item__text">
                        <h6><?php echo $nome ?></h6>
                        <span>R$ <?php echo $valor ?></span>
                    </div>
                </a>

              <?php } ?>


            </div>



            <div class="latest-prdouct__slider__item">

              <?php 
              $query = $pdo->query("SELECT * FROM produtos where ativo = 'Sim' and estoque > 0 order by id desc limit 6,3 ");
              $res = $query->fetchAll(PDO::FETCH_ASSOC);

              for ($i=0; $i < count($res); $i++) { 
                foreach ($res[$i] as $key => $value) {
                }

                $nome = $res[$i]['nome'];
                $valor = $res[$i]['valor'];
                $nome_url = $res[$i]['nome_url'];
                $imagem = $res[$i]['imagem'];
                $promocao = $res[$i]['promocao'];
                $id = $res[$i]['id'];

                if($promocao == 'Sim'){
                  $queryp = $pdo->query("SELECT * FROM promocoes where id_produto = '$id' ");
                  $resp = $queryp->fetchAll(PDO::FETCH_ASSOC);
                  $valor = $resp[0]['valor'];
                  $valor = number_format($valor, 2, ',', '.');
                }else{
                  $valor = number_format($valor, 2, ',', '.');
                }
                ?>


                <a href="produto-<?php echo $nome_url ?>" class="latest-product__item">
                    <div class="latest-product__item__pic">
                        <img src="img/produtos/<?php echo $imagem ?>" alt="">
                    </div>
                    <div class="latest-product__item__text">
                        <h6><?php echo $nome ?></h6>
                        <span>R$ <?php echo $valor ?></span>
                    </div>
                </a>

              <?php } ?>


            </div>


          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="latest-product__text">
          <h4>Mais Vendidos</h4>
          <div id="maisVendidos" class="latest-product__slider owl-carousel">


            <div class="latest-prdouct__slider__item">

              <?php 
              $query = $pdo->query("SELECT * FROM produtos where ativo = 'Sim' and estoque > 0 order by vendas desc limit 3 ");
              $res = $query->fetchAll(PDO::FETCH_ASSOC);

              for ($i=0; $i < count($res); $i++) { 
                foreach ($res[$i] as $key => $value) {
                }

                $nome = $res[$i]['nome'];
                $valor = $res[$i]['valor'];
                $nome_url = $res[$i]['nome_url'];
                $imagem = $res[$i]['imagem'];
                $promocao = $res[$i]['promocao'];
                $id = $res[$i]['id'];

                if($promocao == 'Sim'){
                  $queryp = $pdo->query("SELECT * FROM promocoes where id_produto = '$id' ");
                  $resp = $queryp->fetchAll(PDO::FETCH_ASSOC);
                  $valor = $resp[0]['valor'];
                  $valor = number_format($valor, 2, ',', '.');
                }else{
                  $valor = number_format($valor, 2, ',', '.');
                }
                ?>


                <a href="produto-<?php echo $nome_url ?>" class="latest-product__item">
                    <div class="latest-product__item__pic">
                        <img src="img/produtos/<?php echo $imagem ?>" alt="">
                    </div>
                    <div class="latest-product__item__text">
                        <h6><?php echo $nome ?></h6>
                        <span>R$ <?php echo $valor ?></span>
                    </div>
                </a>

              <?php } ?>


            </div>


            <div class="latest-prdouct__slider__item">

              <?php 
              $query = $pdo->query("SELECT * FROM produtos where ativo = 'Sim' and estoque > 0 order by vendas desc limit 3,3 ");
              $res = $query->fetchAll(PDO::FETCH_ASSOC);

              for ($i=0; $i < count($res); $i++) { 
                foreach ($res[$i] as $key => $value) {
                }

                $nome = $res[$i]['nome'];
                $valor = $res[$i]['valor'];
                $nome_url = $res[$i]['nome_url'];
                $imagem = $res[$i]['imagem'];
                $promocao = $res[$i]['promocao'];
                $id = $res[$i]['id'];

                if($promocao == 'Sim'){
                  $queryp = $pdo->query("SELECT * FROM promocoes where id_produto = '$id' ");
                  $resp = $queryp->fetchAll(PDO::FETCH_ASSOC);
                  $valor = $resp[0]['valor'];
                  $valor = number_format($valor, 2, ',', '.');
                }else{
                  $valor = number_format($valor, 2, ',', '.');
                }
                ?>


                <a href="produto-<?php echo $nome_url ?>" class="latest-product__item">
                    <div class="latest-product__item__pic">
                        <img src="img/produtos/<?php echo $imagem ?>" alt="">
                    </div>
                    <div class="latest-product__item__text">
                        <h6><?php echo $nome ?></h6>
                        <span>R$ <?php echo $valor ?></span>
                    </div>
                </a>

              <?php } ?>


            </div>



            <div class="latest-prdouct__slider__item">

              <?php 
              $query = $pdo->query("SELECT * FROM produtos where ativo = 'Sim' and estoque > 0 order by vendas desc limit 6,3 ");
              $res = $query->fetchAll(PDO::FETCH_ASSOC);

              for ($i=0; $i < count($res); $i++) { 
                foreach ($res[$i] as $key => $value) {
                }

                $nome = $res[$i]['nome'];
                $valor = $res[$i]['valor'];
                $nome_url = $res[$i]['nome_url'];
                $imagem = $res[$i]['imagem'];
                $promocao = $res[$i]['promocao'];
                $id = $res[$i]['id'];

                if($promocao == 'Sim'){
                  $queryp = $pdo->query("SELECT * FROM promocoes where id_produto = '$id' ");
                  $resp = $queryp->fetchAll(PDO::FETCH_ASSOC);
                  $valor = $resp[0]['valor'];
                  $valor = number_format($valor, 2, ',', '.');
                }else{
                  $valor = number_format($valor, 2, ',', '.');
                }
                ?>


                <a href="produto-<?php echo $nome_url ?>" class="latest-product__item">
                    <div class="latest-product__item__pic">
                        <img src="img/produtos/<?php echo $imagem ?>" alt="">
                    </div>
                    <div class="latest-product__item__text">
                        <h6><?php echo $nome ?></h6>
                        <span>R$ <?php echo $valor ?></span>
                    </div>
                </a>
              <?php } ?>


            </div>


          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="latest-product__text">

          <h4>Promoções <small> ver tudo</small></h4>
          <div id="combosPromocionais" class="latest-product__slider owl-carousel">



            <div class="latest-prdouct__slider__item">

              <?php 
              $query = $pdo->query("SELECT * FROM produtos where promocao = 'Sim' and ativo = 'Sim' and estoque > 0 limit 3 ");
              $res = $query->fetchAll(PDO::FETCH_ASSOC);

              for ($i=0; $i < count($res); $i++) { 
                foreach ($res[$i] as $key => $value) {
                }

                $nome = $res[$i]['nome'];
                $valor = $res[$i]['valor'];
                $nome_url = $res[$i]['nome_url'];
                $imagem = $res[$i]['imagem'];
                $promocao = $res[$i]['promocao'];
                $id = $res[$i]['id'];

                if($promocao == 'Sim'){
                  $queryp = $pdo->query("SELECT * FROM promocoes where id_produto = '$id' ");
                  $resp = $queryp->fetchAll(PDO::FETCH_ASSOC);
                    $valor_desc = $resp[0]['valor'];
                    $desconto = $resp[0]['desconto'];
                    $valor_desc = number_format($valor_desc, 2, ',', '.');
                }else{
                  $valor = number_format($valor, 2, ',', '.');
                }
                ?>


                <a href="produto-<?php echo $nome_url ?>" class="latest-product__item">
                    <div class="latest-product__item__pic">
                        <img src="img/produtos/<?php echo $imagem ?>" alt="">
                    </div>
                    <div class="latest-product__item__text">
                        <h6><?php echo $nome ?></h6>
                         <strike> R$ <?php echo $valor ?> </strike>
                         <small>-<?php echo $desconto ?>%</small>
                         <span> R$ <?php echo $valor_desc ?></span>
                    </div>
                    
                </a>

              <?php } ?>
                
                


            </div>


            <div class="latest-prdouct__slider__item">

              <?php 
              $query = $pdo->query("SELECT * FROM produtos where promocao = 'Sim' and ativo = 'Sim' and estoque > 0 limit 3,3 ");
              $res = $query->fetchAll(PDO::FETCH_ASSOC);

              for ($i=0; $i < count($res); $i++) { 
                foreach ($res[$i] as $key => $value) {
                }

                $nome = $res[$i]['nome'];
                $valor = $res[$i]['valor'];
                $nome_url = $res[$i]['nome_url'];
                $imagem = $res[$i]['imagem'];
                $promocao = $res[$i]['promocao'];
                $id = $res[$i]['id'];

                if($promocao == 'Sim'){
                  $queryp = $pdo->query("SELECT * FROM promocoes where id_produto = '$id' ");
                  $resp = $queryp->fetchAll(PDO::FETCH_ASSOC);
                    $valor_desc = $resp[0]['valor'];
                    $desconto = $resp[0]['desconto'];
                    $valor_desc = number_format($valor_desc, 2, ',', '.');
                }else{
                  $valor = number_format($valor, 2, ',', '.');
                }
                ?>


                <a href="produto-<?php echo $nome_url ?>" class="latest-product__item">
                    <div class="latest-product__item__pic">
                        <img src="img/produtos/<?php echo $imagem ?>" alt="">
                    </div>
                    <div class="latest-product__item__text">
                        <h6><?php echo $nome ?></h6>
                         <strike> R$ <?php echo $valor ?></strike>
                         <small>-<?php echo $desconto ?>%</small>
                         <span> R$ <?php echo $valor_desc ?></span>
                    </div>
                </a>

              <?php } ?>


            </div>



            <div class="latest-prdouct__slider__item">

              <?php 
              $query = $pdo->query("SELECT * FROM produtos where promocao = 'Sim' and ativo = 'Sim' and estoque > 0 limit 6,3 ");
              $res = $query->fetchAll(PDO::FETCH_ASSOC);

              for ($i=0; $i < count($res); $i++) { 
                foreach ($res[$i] as $key => $value) {
                }

                $nome = $res[$i]['nome'];
                $valor = $res[$i]['valor'];
                $nome_url = $res[$i]['nome_url'];
                $imagem = $res[$i]['imagem'];
                $promocao = $res[$i]['promocao'];
                $id = $res[$i]['id'];

                if($promocao == 'Sim'){
                  $queryp = $pdo->query("SELECT * FROM promocoes where id_produto = '$id' ");
                  $resp = $queryp->fetchAll(PDO::FETCH_ASSOC);
                    $valor_desc = $resp[0]['valor'];
                    $desconto = $resp[0]['desconto'];
                    $valor_desc = number_format($valor_desc, 2, ',', '.');
                }else{
                  $valor = number_format($valor, 2, ',', '.');
                }
                ?>


                <a href="produto-<?php echo $nome_url ?>" class="latest-product__item">
                    <div class="latest-product__item__pic">
                        <img src="img/produtos/<?php echo $imagem ?>" alt="">
                    </div>
                    <div class="latest-product__item__text">
                        <h6><?php echo $nome ?></h6>
                         <strike> R$ <?php echo $valor ?></strike>
                         <small>-<?php echo $desconto ?>% </small>
                         <span> R$ <?php echo $valor_desc ?></span>
                    </div>
                </a>
              <?php } ?>


            </div>



          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
require_once("rodape.php");
require_once("modal-carrinho.php");

?>







